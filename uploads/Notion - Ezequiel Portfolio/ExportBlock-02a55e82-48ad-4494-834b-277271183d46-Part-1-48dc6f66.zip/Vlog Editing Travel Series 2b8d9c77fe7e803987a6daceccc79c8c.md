# Vlog Editing: Travel Series

Problem → Solution: Raw travel footage sitting on a hard drive — edited into watchable vlogs worth sharing
Tools Used: final cut pro
Tags: video editing
Status: Finished

I've been into video editing for a while, but mostly through Adobe Premiere. This project was a chance to properly explore Final Cut Pro using footage I actually cared about: our own travel videos.

The goal was simple. We had raw clips sitting on a drive and I wanted to turn them into something actually enjoyable to watch.

## The Process

Nothing fancy, just how I approach editing:

**Pass 1 (Rough Cut)** — Pull all the clips in, cut out the obvious dead weight. Get the story or sequence down without worrying too much about pacing yet.

**Pass 2 (Tight Cut)** — This is where the real editing happens. Tightening transitions, fixing pacing, making sure nothing overstays its welcome. Adding background music, sound effects, and making sure the audio levels feel natural throughout.

The goal is always the same: make it enjoyable for someone who wasn't there.

## The Videos

**The Dahilayan Vlog** — our own footage from a trip to Dahilayan Adventure Park in Bukidnon. Mix of outdoor activities and general travel footage. [Watch on Google Drive](https://drive.google.com/file/d/1AXWyTFf6cYKM_d12qM1chlg6J3d4EcLX/view?usp=sharing)

**Walking Through Intramuros** — I shot this one myself during a visit to Manila using a DJI Osmo Pocket 3. The idea was a simple walking vlog, just letting the place speak for itself. Intramuros has a lot of history and character, so the editing was mostly about getting out of the way and letting the visuals carry it.

[https://www.youtube.com/watch?v=zlfLqllHMjM](https://www.youtube.com/watch?v=zlfLqllHMjM)