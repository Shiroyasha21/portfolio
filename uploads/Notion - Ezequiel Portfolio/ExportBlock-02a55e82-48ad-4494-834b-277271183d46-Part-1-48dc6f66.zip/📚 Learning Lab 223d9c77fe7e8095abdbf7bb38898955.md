# 📚 Learning Lab

<aside>
💡

This is where I document my experiments, learnings, and half-baked ideas — AI tools, Sheets scripts, APIs I’m testing, and workflow insights.

It’s messy on purpose.

</aside>

[Learning Log](Learning%20Log%20223d9c77fe7e80a290dad768696226c0.csv)