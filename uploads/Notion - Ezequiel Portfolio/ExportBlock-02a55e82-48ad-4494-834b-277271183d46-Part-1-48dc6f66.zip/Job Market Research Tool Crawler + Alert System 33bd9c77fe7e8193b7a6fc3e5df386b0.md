# Job Market Research Tool: Crawler + Alert System

Problem → Solution: Manually browsing job boards to research salary ranges, in-demand skills, and work types gives you a snapshot at best. Built an automated crawler that collects and structures listing data into a searchable sheet, turning a daily manual task into an ongoing research pipeline.
Tools Used: Apps Script, Git, Google Sheets API, JavaScript, Node.js, VSCode
Status: Finished

This project started as a practical problem: understanding the remote job market takes time. Browsing listings one by one gives you a rough feel, but not real data. What are roles actually paying? What skills keep showing up? What's the difference between part-time and full-time rates for the same kind of work?

The idea was to stop guessing and start collecting. Instead of reading listings manually, build something that reads them for you and stores everything in a structured format you can actually analyze.

## The Goal

Build a crawler that runs on demand, pulls job listings by keyword, and logs everything into a Google Sheet in a clean, consistent structure. The sheet becomes the research database: filterable, sortable, and growing every time the crawler runs.

Secondary goal: make it easy to run. No command-line expertise required. Just a double-click.

## General Flow

```
Run crawler (double-click .bat file on Windows)
    → Launches in terminal via Node.js
    → Searches listings by keyword
    → Pulls full listing details per result
    → Checks each listing against existing Sheet data
        → New listing     → Appended to master sheet (bolded for visibility)
        → Updated listing → Old version moved to archive sheet, new version replaces it
        → No change       → Skipped
    → Sheet updated with fresh, deduplicated data
```

## What the Data Looks Like

For every listing, the crawler captures and structures:

- **Title** — the job title as listed
- **Salary (raw)** — the original salary text from the listing
- **Salary (cleaned)** — normalized to a usable number
- **Min / Max salary** — parsed range where available
- **Currency and unit** — hourly, monthly, fixed, etc.
- **Type of work** — full-time, part-time, project-based
- **Hours per week** — where specified
- **Required skills** — pulled from the listing body
- **Employer info** — about the employer section
- **Apply link** — direct link to the application
- **Scraped at** — timestamp of when the data was collected
- **Job ID** — unique identifier used for deduplication

Salary normalization was intentional. Raw salary text from listings is messy and inconsistent. Parsing it into clean numbers makes it actually useful for comparison across listings.

## How Deduplication and Archiving Works

This was one of the more interesting parts to build. Every listing has a unique Job ID. When the crawler runs, it checks each result against the IDs already in the sheet:

- If the ID doesn't exist yet, the row is appended and bolded so new entries stand out visually.
- If the ID exists but the listing has been updated (detected by comparing dates), the old row gets archived to a separate sheet with a timestamp, and the master row is updated with the fresh data.
- If nothing has changed, the listing is skipped entirely.

This means the master sheet always reflects current data, while the archive sheet keeps a full history of how listings changed over time.

Here's a simplified version of that logic:

```jsx
for (const j of jobs) {
  if (!j.jobId) continue;
  const existing = idMap.get(j.jobId);

  if (existing) {
    const oldDate = new Date(existing.dateUpdated);
    const newDate = new Date(j.dateUpdated);

    if (!isNaN(newDate.getTime()) && newDate > oldDate) {
      // Archive the old row, update with new data
      archives.push([...existing.rowData, j.dateUpdated]);
      updates.push({ rowNum: existing.rowNum, values: buildRow(j) });
    }
    // else: no change, skip

  } else {
    // Brand new listing
    appends.push(buildRow(j));
  }
}
```

## Tools and Environment

**Node.js** — the crawler runs entirely in Node, using the Google Sheets API directly rather than Apps Script. A step up from previous projects and required setting up proper API credentials.

**Google Sheets API (v4)** — not just Apps Script this time. Full API authentication using a credentials file, with separate calls for reading, appending, updating, and batch formatting.

**VSCode + GitHub Copilot** — Copilot was used throughout as a development aid, particularly useful for working through the Sheets API structure and handling edge cases in the deduplication logic.

**Git** — version controlled throughout as the project grew from a basic crawler into something with filtering, archiving, and formatting logic.

**Windows .bat launcher** — to make it easy to run without opening a terminal manually. Double-clicking the file launches the crawler in a command prompt window, shows the output live, and keeps the window open afterward.

## What I Learned

This was the first project where I worked outside of Google Apps Script into the full Sheets API with Node.js. The authentication setup alone was a learning curve: understanding service accounts, credentials files, and scopes.

Working with Copilot inside VSCode changed how I approached building. It's less about generating code and more about having something to think out loud with. The best parts of this project came from understanding what the suggested code was doing and then improving on it.

Git also became more useful than I expected. Being able to roll back when something broke, and seeing the history of how the project evolved, made the whole process feel more structured.

The deduplication and archive logic was the part I'm most satisfied with. It's the kind of thing that's easy to skip and hard to notice is missing, until the data gets messy.

---

## Part 2: Real-Time Alert System

The crawler solved the research problem. But going through the data, a different problem became obvious: in remote job hunting, timing matters. A posting that's a few hours old already has a pile of applicants. Being early is a real advantage.

So the second part of this project was built around that insight. Instead of running the crawler manually and checking the sheet, the goal was to get notified the moment something new appears, without having to do anything.

### How It Works

The alert system runs on Google Apps Script with a time-based trigger, checking every 15 to 20 minutes. Rather than scanning every listing on the page blindly, it watches only the top three posts and reads their timestamps.

The logic is simple but effective:

- On each run, it reads the timestamps of the top three listings
- It compares them against the timestamps stored from the previous run
- If any timestamp is new or has shifted, it means a fresh posting appeared
- An email alert fires immediately with the job title and a direct link to apply
- Duplicate detection is built in to avoid false alerts if posts are just reordered

Watching timestamps instead of scanning all job IDs was a deliberate choice. New posts push older ones down, so a change in the top three is a reliable signal that something was posted. It's lighter and more accurate than trying to parse every listing on every check.

### Why This Approach

The research phase showed that certain types of roles get filled fast. Knowing what to look for and being notified immediately when it appears was the practical application of everything the crawler had already gathered. The alert system didn't replace the crawler, it completed it.

### Tools

Google Apps Script, Gmail (via Apps Script), time-based triggers. No extra services, no cost, runs entirely in Google's cloud.