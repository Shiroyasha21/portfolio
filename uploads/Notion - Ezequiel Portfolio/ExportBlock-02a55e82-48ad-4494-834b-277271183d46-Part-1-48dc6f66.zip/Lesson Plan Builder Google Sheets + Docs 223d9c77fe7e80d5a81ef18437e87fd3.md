# Lesson Plan Builder: Google Sheets + Docs

Problem → Solution: Teachers waste time rewriting the same lesson plan structures over and over. This tool turns a filled-out Google Sheet into a complete, formatted lesson plan document in one click.
Tools Used: Apps Script, Google Sheets, OpenAI API
Tags: Automation, Data Processing, Productivity
Status: Finished
Prompt: Convert this spreadsheet data into a properly formatted lesson plan with objectives, activities, and assessment sections. Include header formatting and maintain the structure outlined in column A.

Teachers already know Google Sheets. That was the whole starting point.

The problem this project tries to solve is simple: writing lesson plans is repetitive. The structure is almost always the same, the sections are the same, and yet teachers still end up retyping or reformatting everything from scratch each time. It's the kind of task that shouldn't take as long as it does.

So instead of asking teachers to learn a new tool, I built around what they already use.

## How It Works

The Google Sheet acts as the entire database. Every part of the lesson plan has its own column: objectives, activities, materials, assessment, and so on. Teachers just fill in the relevant fields for a given lesson, the same way they would update any spreadsheet.

When they're ready, they hit a menu button inside the sheet. That triggers an Apps Script that reads the data row by row and merges everything into a properly formatted Google Doc, outputting a complete, ready-to-use lesson plan.

The sheet also stores past lesson materials, so teachers can reference or reuse previous content without digging through old documents.

## The Thinking Behind It

The goal was plug-and-play. No coding knowledge needed, no extra apps to install, no learning curve. Just a sheet with clear fields and a button that does the work.

It's also an older project, but it represents something I still think about: automation doesn't have to be complex to be useful. Sometimes the best solution is just removing the steps that were always unnecessary.

## Tools Used

Google Sheets, Google Apps Script

---

## See It

**The Sheet** — the actual Lesson Plan Builder spreadsheet with all the fields, database, and menu button.

[Open in Google Sheets](https://docs.google.com/spreadsheets/d/1KJIkrE4u-xSnAzkZ4j9__bpPbCUif4WbZCYQN1tXPwE/edit?usp=sharing)

**Sample Output** — a generated lesson plan document, exactly what the tool produces after hitting the menu button.

[Open in Google Docs](https://docs.google.com/document/d/1CxLoXhpdl_of6P0VBWVz0GcEkXM7KKxfgLGUs6SsRdU/edit?tab=t.0)