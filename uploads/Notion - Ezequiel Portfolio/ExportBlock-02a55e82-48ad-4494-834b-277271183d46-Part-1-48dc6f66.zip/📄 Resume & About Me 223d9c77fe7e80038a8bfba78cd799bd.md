# 📄 Resume & About Me

## About Me

I'm Ezequiel, a Virtual Assistant with 3 years of remote experience in operations, social media systems, and workflow automation.

I started out doing the usual VA work: research, data entry, documentation. Over time I found myself drawn to the part most people skip, which is building the systems behind the work. I've managed complex multi-account environments, built tracking tools from scratch in Google Sheets, and integrated AI to cut down on repetitive tasks.

Outside of client work, I build automations using Apps Script, OpenAI, and Telegram bots. Not because I have to, but because I genuinely enjoy figuring out how things can run better.

I hold a Professional Teaching License (88.20) and a Career Service Professional Eligibility (81.1). Both reflect the same thing I bring to my work: a habit of doing things properly.

---

## Skills and Tools

| Skills | Tools |
| --- | --- |
| Google Sheets Automation | Google Sheets / Apps Script |
| Prompt Engineering | OpenAI / Claude / ChatGPT |
| AI Workflow Integration | Telegram Bot API |
| Social Media Operations | Geelark (cloud phones) |
| Data Parsing and Summarization | Canva / Adobe Creative Suite |
| Content Research and Reporting | Final Cut Pro |
| Multi-account Management | WordPress / GitHub |

---

## My Journey

**Pre-2023** — Before freelancing, spent time learning web development: HTML, CSS, some JavaScript and basic backend concepts. Never finished it fully, but that period built something more useful than a completed course: a way of thinking about problems logically and breaking them down step by step. No AI tools to lean on back then, just reading docs and figuring things out. That foundation is still visible in some early public repositories on [GitHub](https://github.com/Shiroyasha21?tab=repositories).

**2023** — Started freelancing as a Virtual Assistant. Began with the basics: data entry, research, and documentation. Also set up basic WordPress sites during this period. It was the foundation that everything else grew from.

**2024** — Started experimenting with AI prompts and Google Sheets automation. Built a Telegram bot just to understand how bots work from the ground up. Also built the Sheet-to-Doc Lesson Planner around this time.

**2025** — Began managing multi-platform social media accounts at scale using Geelark. Deepened focus on practical AI workflows, Apps Script, and started building more complex tools: the Gmail inbox automation, the job market crawler, and the DailyLog bot.

**2026** — Currently exploring Blender for 3D modelling, with plans to get into 3D printing later this year.

---

📄 [Download My Resume](https://drive.google.com/file/d/1IVFIZiOj_XTrpVBgqYwR9BLkVnaWbl4e/view?usp=sharing)