# DailyLog Bot: Telegram Report to Sheets

Problem → Solution: Remote workers and VAs had no simple way to submit end-of-day reports without logging into a spreadsheet. Built a Telegram bot that accepts a structured daily report and logs it automatically to Google Sheets.
Tools Used: Apps Script, Google Sheets, Webhooks
Tags: Automation, Integration, Logging
Status: Finished

One thing that's always been a bit messy in remote work setups is end-of-day reporting. A VA or remote worker sends a message, it gets buried in a chat thread, and the client either misses it or has to manually copy it somewhere. It's a small friction point, but it adds up.

This project was my attempt to fix that. The idea was to let a worker submit their daily report through Telegram, and have everything automatically logged into a Google Sheet the client can check anytime. No spreadsheet access needed on the worker's side. No manual copying on the client's side.

## How It Works

The bot is built on Google Apps Script, deployed as a Web App and connected to Telegram via a webhook. When a user sends a report, the bot parses the fields and writes the data directly into a connected Google Sheet.

The worker sends a filled-in template like this:

```
DAILY REPORT
--- START ---
Date: 
Minutes Worked: 
Rows Worked: 
Task: 
Notes: 
--- END ---
```

The bot validates each field, catches missing or invalid entries with a clear error message, and logs everything with a timestamp. The sheet captures the username, date, minutes worked, rows worked, task, notes, and a calculated average minutes per row.

Workers can also pull up their own stats through the bot: total entries, total minutes logged, and average speed, all pulled live from the sheet.

## What I Learned

This was my first real project involving things outside of Google Sheets automation, and it pushed me into territory I hadn't worked in before.

**Webhooks and Web Apps** — deploying a Google Apps Script as a live Web App and connecting it to Telegram via webhook, so the bot receives and responds to messages in real time.

**Working with an API** — using the Telegram Bot API directly to handle commands, process inline button interactions, and send structured responses back to users.

**Apps Script as a backend** — using Apps Script not just for spreadsheet work, but as a lightweight server that handles incoming data, runs validation logic, and writes to Sheets on the fly.

The project also reinforced something practical: building with tools the end user already has access to. No extra software, no new accounts, just Telegram and a Google Sheet.

## Tools Used

Google Apps Script, Telegram Bot API, Google Sheets, Webhooks