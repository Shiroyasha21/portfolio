# Ezequiel Burdios | Work & Projects

Hi, I'm Ezequiel, a Virtual Assistant and automation builder based in the Philippines.

I turn messy, repetitive workflows into clean, reliable systems. My work sits at the intersection of operations, AI tools, and practical scripting, built to solve real problems, not just look good on paper.

This space is where I document what I've built, what I'm learning, and who I am as a professional.

<aside>
🧭

**Navigation**

📁 Projects — see the gallery below

📄 [Resume & About Me](https://www.notion.so/223d9c77fe7e80038a8bfba78cd799bd) — Background, skills, and resume download

📚 [Learning Lab](https://www.notion.so/223d9c77fe7e8095abdbf7bb38898955) — Experiments, scripts, and prompt tests

📨 **Contact** — [red.ezequiel@gmail.com](mailto:red.ezequiel@gmail.com)

🐙 **GitHub** — [github.com/Shiroyasha21](http://github.com/Shiroyasha21)

🔗 **Portfolio URL** — [ezequielbportfolio.notion.site](http://ezequielbportfolio.notion.site)

</aside>

[Projects](Projects%20223d9c77fe7e80068234dda7222eb37b.csv)

[📄 Resume & About Me](%F0%9F%93%84%20Resume%20&%20About%20Me%20223d9c77fe7e80038a8bfba78cd799bd.md)

[📚 Learning Lab](%F0%9F%93%9A%20Learning%20Lab%20223d9c77fe7e8095abdbf7bb38898955.md)