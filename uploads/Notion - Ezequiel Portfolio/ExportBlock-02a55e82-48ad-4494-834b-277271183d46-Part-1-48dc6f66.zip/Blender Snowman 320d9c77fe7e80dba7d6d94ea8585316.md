# Blender: Snowman

Tools Used: Blender
Status: Finished

I've always been curious about 3D modelling, mostly because of where I want to take it eventually: 3D printing. Before investing in hardware though, I figured learning Blender first was the smarter move.

This snowman was my first real project. I followed a 14-part YouTube tutorial by Ryan King Art, which turned out to be a solid introduction to how Blender actually works, not just the buttons, but the thinking behind it.

## What I Worked On

By the end of the tutorial I had hands-on experience with:

- Modeling shapes from scratch and editing meshes
- Navigating the Blender interface and learning the keyboard shortcuts that make it usable
- Working with nodes, materials, and modifiers to add detail
- Setting up camera and lighting for a proper composition
- Compositing the final rendered image

## Where I'm At Now

This project got me comfortable with the core workflow. I'm still in the tutorial phase, building a stronger foundation before moving into original work. The goal eventually is to design my own models for 3D printing.

## Output

Below is the final rendered image from the project:

![The Snowman Result.jpg](The_Snowman_Result.jpg)