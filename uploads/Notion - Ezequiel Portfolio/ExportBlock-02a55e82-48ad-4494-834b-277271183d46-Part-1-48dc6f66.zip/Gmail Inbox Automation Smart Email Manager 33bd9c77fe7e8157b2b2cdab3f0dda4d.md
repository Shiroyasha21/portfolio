# Gmail Inbox Automation: Smart Email Manager

Problem → Solution: Important emails from brands and collaborators get buried in Promotions or spam. Built a Gmail automation that surfaces them, handles initial replies automatically, and keeps the inbox organized without touching it manually.
Tools Used: Apps Script, Google Sheets
Status: Finished

Managing brand and collaborator emails manually has a quiet but real cost. Things get buried in Promotions, replies get delayed, and the inbox becomes something you manage instead of something that works for you.

This project started from a specific need: automatically catch incoming emails from known brands and contacts, bring them to the primary inbox, and handle the initial response without any manual intervention. Over time it grew into something more generalizable — a reusable inbox management layer built entirely on Google Apps Script.

> **This was built and deployed as part of a real freelance VA engagement**, handling live brand email management for a client. What's documented here is the general-purpose version of that system.
> 

## The Goal

Build an automation that runs every 6 hours, finds unread emails matching defined rules, processes them consistently, and replies when appropriate. The rules live in a Google Sheet so anyone can adapt it to their own inbox without touching the code.

## How It Works

```
Trigger fires every 6 hours
    → Loads rules from "brands" tab (domain + keywords + optional custom reply)
    → Searches Gmail for unread matches
    → For each matched thread:
        → Already processed? Skip (dedup via PropertiesService)
        → Move to Primary inbox (strips Promotions/Social/Updates labels)
        → Star + mark as important
        → Add sender to Google Contacts
        → Mark as read
        → Reply logic:
            → Auto-reply or bounce detected? Skip
            → Cooldown active (12 hrs per domain)? Skip
            → Collab keyword in subject or body? Send formal collab reply
            → Otherwise: send random reply from "replies" tab
```

## The Sheet Setup

Two tabs keep everything clean and editable:

**brands** — one row per sender rule. Columns: domain, keywords (comma-separated), and an optional reply override for that specific sender. If the override is blank, the script falls back to the random reply pool.

**replies** — a pool of reply lines, randomly selected per send. Can be as large as needed and reused when the pool runs out. Keeping this separate means updating tone or copy never requires touching the script.

## The Interesting Problem

The first version had a bug that only showed up during real testing. When the script replied to a brand email, their system sent back an auto-reply as a new email entirely. That new email matched the same rules, so the script processed it again and replied to that too. Back and forth until the cooldown kicked in.

The fix was two-layered. First, add pattern detection on the subject and body to catch auto-replies, bounces, and no-reply addresses before attempting any response. Second, add a 12-hour cooldown per domain as a hard backstop: even if something slips through the detection, the script won't reply to the same sender more than once within that window.

Both layers run independently, so either one can catch what the other misses. The cooldown in particular was the more reliable fix since it doesn't depend on correctly identifying the email type.

## The Collab Reply Angle

One extension worth building out: if an incoming email contains words like "collab", "collaboration", "partnership", or "sponsorship" in the subject or body, trigger a formal, professional reply instead of a random one from the pool.

This makes the automation genuinely useful for creators, social media managers, or VAs handling brand accounts — where a collab inquiry deserves a proper response, not a generic line. The reply override column in the brands tab already supports custom replies per sender, so this would just add a keyword-based trigger layer on top.

## How Else This Can Be Used

The core logic is reusable across a lot of different inbox scenarios:

**Freelancers** — auto-reply to inquiries containing "rates", "availability", or "interested in your services" with a holding message while you prepare a proper proposal.

**Hiring managers** — acknowledge job applications automatically the moment they arrive, so candidates know their email landed.

**Small support teams** — route emails by keyword to the right label or draft a holding reply while the ticket is being reviewed.

**Newsletter managers** — filter real replies from auto-generated ones so nothing genuine gets missed in a high-volume inbox.

The sheet-based rules mean adapting it to any of these cases is just a matter of updating the brands and replies tabs.

## Snippet

Here's the cooldown and auto-reply detection logic, which is the core of what makes the automation reliable rather than just functional:

```jsx
// Detect auto-replies and bounces before attempting to reply
const isAutoReply = /auto.?reply|out of office|no.?reply|automatic response|ticket received/i
  .test(subject);
const isBounce = /message not delivered|delivery failed|undeliverable/i
  .test(subject + " " + body);

// 12-hour cooldown per domain
function hasRepliedRecently(domain) {
  const key = "replied_" + domain.replace("@", "");
  const last = PROPS.getProperty(key);
  if (!last) return false;
  const elapsed = Date.now() - parseInt(last);
  return elapsed < 12 * 60 * 60 * 1000;
}
```

## Tools Used

Google Apps Script, Gmail API, Google People API, Google Sheets, time-based triggers

## What I Learned

This project pushed into territory that felt closer to backend development than spreadsheet automation. A few things stood out:

**PropertiesService for state** — using Apps Script's PropertiesService to track processed threads and cooldown timestamps across runs. Without this, the script would reprocess the same emails every time it fired.

**Gmail label manipulation via REST** — moving emails to Primary isn't just moving them to inbox. It requires explicitly removing category labels like CATEGORY_PROMOTIONS using the Gmail REST API directly, which is a different call from the standard GmailApp methods.

**People API for contact creation** — automatically adding senders to Google Contacts using the People API, with deduplication via PropertiesService so the same contact isn't created twice.

**Building for edge cases first** — the auto-reply bug early on shifted how the whole script was approached. Instead of building the happy path and patching problems later, the detection and cooldown layers were built as core parts of the logic from the start.